import unittest
import requests

class TestWeatherAPI(unittest.TestCase):
    def setUp(self):
        self.api_key = "8bc7a9ebeeaadf8a90787ba53a16885f"
        self.base_url = "http://api.openweathermap.org/data/2.5/weather"
        self.params = {
            "q": "Bangalore",
            "appid": self.api_key,
            "units": "metric"
        }

    def test_api_response_ok(self):
        """Test if API responds with status code 200"""
        response = requests.get(self.base_url, params=self.params)
        self.assertEqual(response.status_code, 200)

    def test_api_contains_main_block(self):
        """Test if response contains expected 'main' block"""
        response = requests.get(self.base_url, params=self.params)
        data = response.json()
        self.assertIn("main", data)
        self.assertIn("temp", data["main"])

if __name__ == "__main__":
    unittest.main()
